from django.urls import path,re_path,include

app_name = 'appconfig'
urlpatterns = [
]
