from django.db import models

# Create your models here.
from django.db import models
from 基于卷积神经网络的茶叶病虫害检测系统 import settings
import os
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.auth.models import AbstractUser
# Create your models here.
from django.templatetags.static import static

def user_directory_path(instance, filename):
    # 文件将上传到 MEDIA_ROOT/user_<pk>/<filename>
    return f'user_{instance.pk}/{filename}'

class User(AbstractUser):
    email = models.EmailField(null=True,verbose_name='邮箱')
    xingming = models.CharField(max_length=20,null=True,verbose_name='姓名')
    dianhua = models.CharField(max_length=20,null=True,verbose_name='电话')
    dizhi = models.TextField(null=True,verbose_name='地址')
    xingbie = models.CharField(max_length=20, null=True,verbose_name='性别')
    shengri = models.DateField(null=True, verbose_name='生日')
    touxiang = models.ImageField(upload_to=user_directory_path, null=True, blank=True, verbose_name='头像')
    def get_image_url(self):
        if self.touxiang and hasattr(self.touxiang, 'url'):
            return self.touxiang.url
        else:
            return static('default/user-1.jpg')
    def __str__(self):
        return self.username

    class Meta:
        db_table = 'user'
        verbose_name = '用户信息'

@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created and instance.touxiang:
        # 创建用户文件夹
        user_media_path = os.path.join(settings.MEDIA_ROOT, f'user_{instance.pk}')
        os.makedirs(user_media_path, exist_ok=True)
        # 复制头像到用户文件夹
        avatar_path = instance.touxiang.path
        new_avatar_path = os.path.join(user_media_path, os.path.basename(avatar_path))
        os.rename(avatar_path, new_avatar_path)
        instance.touxiang.name = user_directory_path(instance, os.path.basename(avatar_path))
        instance.save()



class IdentifyLog(models.Model):
    name = models.CharField(max_length=255, null=True, verbose_name='识别编码')
    time = models.CharField(max_length=255, null=True, verbose_name='时间')
    result = models.CharField(max_length=255, null=True, verbose_name='结果')
    result_real = models.CharField(max_length=255, null=True, verbose_name='是否正确')
    image = models.ImageField(upload_to='identify_log', null=True, blank=True, verbose_name='识别图像')
    def get_image_url(self):
        if self.image and hasattr(self.image, 'url'):
            return self.image.url
        else:
            return static('default/default_img.jpg')
    class Meta:
        db_table = 'IdentifyLog'
        verbose_name = '识别记录'
        verbose_name_plural = '识别记录'  # 如果是复数形式

    def __str__(self):
        return self.result

class Yf(models.Model):
    name = models.CharField(max_length=255, null=True, verbose_name='病虫害')
    defend = models.CharField(max_length=255, null=True, verbose_name='防治方法')
