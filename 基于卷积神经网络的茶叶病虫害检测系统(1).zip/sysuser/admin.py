from django.contrib import admin

# Register your models here.


from django.http import HttpResponse
from .models import *
import csv





# 后台头像显示
from django.utils.html import format_html

# 导出csv
def export_to_csv(modeladmin, request, queryset):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="export.csv"'
    writer = csv.writer(response)
    fields = [field.name for field in queryset.model._meta.fields]
    writer.writerow(fields)
    for obj in queryset:
        row = [getattr(obj, field) for field in fields]
        writer.writerow(row)
    return response

export_to_csv.short_description = "导出到CSV"


# search

@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ('username', 'email', 'dianhua', 'dizhi', 'xingbie', 'show_avatar', 'shengri')  # 展示的字段
    search_fields = ['username', 'email', 'dianhua', 'dizhi', 'xingbie', 'shengri']

    def show_avatar(self, obj):
        if obj.touxiang:
            return format_html('<img src="{}" width="50" height="50" />', obj.touxiang.url)
        return "无头像"
    show_avatar.short_description = '头像'


@admin.register(IdentifyLog)
class IdentifyLogAdmin(admin.ModelAdmin):
    list_display = ('name', 'time', 'result', 'result_real')
    list_editable = ('result_real',)
    list_display_links = ['name']

    list_filter = ['name', 'time', 'result', 'result_real']


    actions = [export_to_csv]
    # ordering = ['date', 'max_wendu']


@admin.register(Yf)
class YfAdmin(admin.ModelAdmin):
    list_display = ('name', 'defend')
    actions = [export_to_csv]
    search_fields = ['name', 'defend']


#后台管理样式设置
from appconfig import adminconfig
admin.site.site_header = adminconfig.site_header  # 设置header
admin.site.site_title = adminconfig.site_title  # 设置title
admin.site.index_title = adminconfig.index_title

# django表注册
from django.contrib.sessions.models import Session
from django.contrib.admin.models import LogEntry
from django.contrib.contenttypes.models import ContentType
from django.contrib.auth.models import Permission
from captcha.models import CaptchaStore

# session
@admin.register(Session)
class SessionAdmin(admin.ModelAdmin):
    list_display = ('session_key', 'expire_date', 'session_data')
# 日志记录
@admin.register(LogEntry)
class LogEntryAdmin(admin.ModelAdmin):
    list_display = ('action_time', 'user', 'content_type', 'object_id', 'object_repr', 'action_flag')

@admin.register(ContentType)
class ContentTypeAdmin(admin.ModelAdmin):
    list_display = ('app_label', 'model')

@admin.register(Permission)
class PermissionAdmin(admin.ModelAdmin):
    list_display = ('name', 'content_type', 'codename')


# 注册 CaptchaStore 模型 (django-simple-captcha)
@admin.register(CaptchaStore)
class CaptchaStoreAdmin(admin.ModelAdmin):
    list_display = ('hashkey', 'challenge', 'response','expiration')


