from django.urls import path, re_path, include
from .views import *

app_name = 'sysuser'
urlpatterns = [
    path('sysuser_login', sysuser_login, name='sysuser_login'),
    path('sysuser_register', sysuser_register, name='sysuser_register'),
    path('sysuser_logout',sysuser_logout, name='sysuser_logout'),
    path('account',account,name='account'),
    path('user_exist',user_exist,name='user_exist'),
    path('user_email_exist',user_email_exist,name='user_email_exist')
]

from django.conf.urls.static import static
from django.conf import settings
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)