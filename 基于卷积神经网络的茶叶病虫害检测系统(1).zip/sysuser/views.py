from io import BytesIO

from django.core.files.base import ContentFile
from django.shortcuts import render,redirect,HttpResponse
from django.http import JsonResponse
from .models import *

from 基于卷积神经网络的茶叶病虫害检测系统.settings import DATABASE_NAME,DATABASE_USER,DATABASE_PSW,DATABASE_PORT,DATABASE_HOST
from apptools.apptools import *
from PIL import Image





from django.contrib.auth import authenticate, login,logout
def sysuser_login(request):
    if request.method == 'GET':
        # return render(request, 'app/login_register.html', locals())
        return render(request, 'app/authentication-login.html', locals())
    elif request.method == 'POST':
        zhanghao = request.POST.get('zhanghao')
        mima = request.POST.get('mima')
        print(zhanghao, mima)
        user = authenticate(username=zhanghao, password=mima)
        if user:
            login(request, user)
            print(user.id, user.username)
            return HttpResponse(user.username)
        else:
            return HttpResponse(0)

def sysuser_register(request):
    if request.method == 'GET':
        # return render(request, 'app/login_register.html', locals())
        return render(request, 'app/authentication-register.html', locals())
    elif request.method == 'POST':
        print(request.POST)
        zhanghao = request.POST.get('zhanghao')
        mima = request.POST.get('mima')
        email = request.POST.get('email')
        # 为后续的判断做准备
        user = User.objects.filter(username=zhanghao).first()
        if user is not None:
            print('用户已存在')
            return HttpResponse(1)
        elif User.objects.filter(email=email).first() is not None:
            print('邮箱已存在')
            return HttpResponse(2)
        else:
            new_user = User.objects.create_user(username=zhanghao, password=mima, email=email)
            new_user.save()
            print(new_user)
            return HttpResponse(0)

def sysuser_logout(request):
    logout(request)
    return redirect('appcenter:index')

def logout_view(request):
    from django.contrib.auth import logout
    logout(request)
    request.session.flush()
    response = redirect("/admin")
    return response


def account(request):
    if request.method == "GET":
        return render(request, 'app/account.html', locals())
    elif request.method == "POST":
        print(request.POST)
        zhanghao = request.POST.get('zhanghao')
        # 获取 POST 请求的数据
        mima = request.POST.get('mima')
        xingming = request.POST.get('xingming')
        email = request.POST.get('email')
        dianhua = request.POST.get('dianhua')
        dizhi = request.POST.get('dizhi')
        shengri = request.POST.get('shengri')
        xingbie = request.POST.get('xingbie')
        image = request.FILES.get('image')
        user = request.user
        if user.is_authenticated:
            if zhanghao:
                user.username = zhanghao
            if xingming:
                user.xingming = xingming
            if email:
                user.email = email
            if mima:
                user.password = mima
            if dianhua:
                user.dianhua = dianhua
            if dizhi:
                user.dizhi = dizhi
            if shengri:
                user.shengri = shengri
            if xingbie:
                user.xingbie = xingbie
            if image:
                # 打开上传的图片
                touxiang = Image.open(image)
                # 调整图片大小
                touxiang = touxiang.resize((170, 170), Image.LANCZOS)

                # 将调整后的图片保存到内存中
                image_io = BytesIO()
                touxiang.save(image_io, format='JPEG')  # 使用合适的格式保存图片

                # 创建一个新的Django文件对象
                new_avatar = ContentFile(image_io.getvalue(), image.name)
                user.touxiang.save(image.name, new_avatar)
            user.save()

        return HttpResponse(1)
    else:
        return HttpResponse(0)





def user_exist(request):
    if request.method == "GET":
        username = request.GET.get('username', '')
        print(username)
        exists = User.objects.filter(username=username).exists()
        return JsonResponse({'exists': exists})
    return JsonResponse({'exists': False})


def user_email_exist(request):
    if request.method == "GET":
        email = request.GET.get('email', '')
        print(email)
        exists = User.objects.filter(email=email).exists()
        return JsonResponse({'exists': exists})
    return JsonResponse({'exists': False})




