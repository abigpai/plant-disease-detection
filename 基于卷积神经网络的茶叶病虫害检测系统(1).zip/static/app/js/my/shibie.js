// JavaScript代码，用于在文件选择后显示图片预览和异步提交表单
const imageInput = document.getElementById('image-input');
const imagePreviewContainer = document.getElementById('image-preview-container');
const imagePreviewText = document.getElementById('image-preview-text');
const imageForm = document.getElementById('image-form');
const resultText = document.getElementById('result-text');

imageInput.addEventListener('change', function () {
    const file = this.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function (e) {
            imagePreviewContainer.style.backgroundImage = `url('${e.target.result}')`;
            imagePreviewText.style.display = 'none';
        };
        reader.readAsDataURL(file);
    } else {
        imagePreviewContainer.style.backgroundImage = 'none';
        imagePreviewText.style.display = 'block';
    }
});

function submitForm() {
    const fileInput = document.getElementById('image-input');
    const file = fileInput.files[0];

    if (!file) {
        Swal.fire({
            title: '错误！',
            text: '请选择图片！',
            icon: 'error',
            confirmButtonText: '确定'
        })
        return;
    }

    const formData = new FormData();
    formData.append('image', file);

    // 获取CSRF令牌并添加到请求头
    const csrfToken = document.getElementsByName('csrfmiddlewaretoken')[0].value;

    // 发送Ajax请求
    const xhr = new XMLHttpRequest();
    xhr.open('POST', PATH + 'shibie', true);
    xhr.setRequestHeader('X-CSRFToken', csrfToken);
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                // 处理成功的响应，将识别结果更新到页面上
                Swal.fire({
                    title: '提交成功！',
                    text: '点击确定返回结果！',
                    icon: 'success',
                    confirmButtonText: '确定'
                })
                const response = JSON.parse(xhr.responseText);
                let newid = document.getElementById('newid');
                // let newtext_advise = document.getElementById('text_advise')
                // newtext_advise.innerText = response.advises
                newid.value = response.id
                resultText.innerHTML = '识别结果：' + response.result;
            } else {
                // 处理错误的响应
                console.error('请求失败');
            }
        }
    };
    xhr.send(formData);
}

function submitForm1() {
    // 获取表单数据
    var id = document.getElementById('newid').value;
    var result_real = document.getElementById('result_real').value;

    // 创建FormData对象
    var formData = new FormData();
    formData.append('id', id);
    formData.append('result_real', result_real);

    if (id == '' || result_real == '') {
        Swal.fire({
            title: '错误！',
            text: '请先去识别！',
            icon: 'error',
            confirmButtonText: '确定'
        })
        return;
    }

    // 添加CSRF令牌到请求头
    var csrfToken = $('input[name=csrfmiddlewaretoken]').val();
    $.ajax({
        url: PATH + 'jiucuo',
        type: 'POST',
        data: formData,
        contentType: false,
        processData: false,
        beforeSend: function (xhr, settings) {
            xhr.setRequestHeader("X-CSRFToken", csrfToken);
        },
        success: function (data) {
            console.log(data);
            if (data == 1) {
                Swal.fire({
                    title: '提交成功！',
                    text: '',
                    icon: 'success',
                    confirmButtonText: '确定'
                })
            } else {
                Swal.fire({
                    title: '提交失败！',
                    text: '请检查网络连接！',
                    icon: 'error',
                    confirmButtonText: '确定'
                })
            }
        },
        error: function (data) {
            console.log(data);
        }
    });
}
