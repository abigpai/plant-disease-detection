document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('formAccountSettings');
    const uploadInput = document.getElementById('upload');
    const uploadedAvatar = document.getElementById('uploadedAvatar');
    const resetImageBtn = document.getElementById('resetImage');
    const cancelChangesBtn = document.getElementById('cancelChanges');
    const csrftoken = window.myAppConfig.csrftoken;
    const img_path = window.myAppConfig.img_path;
    const formActionUrl = window.myAppConfig.formActionUrl;
    // 上传图像时显示预览
    uploadInput.addEventListener('change', function (e) {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function (event) {
                uploadedAvatar.src = event.target.result;
            };
            reader.readAsDataURL(file);
        }
    });

    // 重置图像
    resetImageBtn.addEventListener('click', function () {
        uploadedAvatar.src = img_path;
        uploadInput.value = ''; // 清除文件输入的值
    });

    // 取消按钮功能：重置所有表单输入
    cancelChangesBtn.addEventListener('click', function () {
        form.reset();
        uploadedAvatar.src = img_path; // 恢复原图像
    });

    // 表单提交
    form.addEventListener('submit', function (e) {
        e.preventDefault();

        // 创建FormData对象
        var formData = new FormData();
        formData.append('zhanghao', document.getElementById('zhanghao').value);
        formData.append('xingming', document.getElementById('xingming').value);
        formData.append('email', document.getElementById('email').value);
        formData.append('mima', document.getElementById('mima').value);
        formData.append('dianhua', document.getElementById('dianhua').value);
        formData.append('dizhi', document.getElementById('dizhi').value);
        formData.append('shengri', document.getElementById('shengri').value);
        formData.append('xingbie', document.getElementById('xingbie').value);
        formData.append('image', uploadInput.files[0]);

        fetch(formActionUrl, { // 请替换为实际的URL
            method: 'POST',
            body: formData,
            headers: {
                'X-CSRFToken': csrftoken // Django 的 CSRF 保护
            }
        })
            .then(response => response.json())
            .then(data => {
                if (data) {
                    Swal.fire({
                        icon: 'success',
                        title: '成功',
                        text: '信息更新成功，需要重新登录',
                        confirmButtonText: '确定'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            console.log(ROOTPATH);
                            window.location.href = ROOTPATH + 'sysuser_login'; // 进入首页
                        }
                    })

                } else {
                    Swal.fire({
                        icon: 'error',
                        title: '错误',
                        text: '信息更新失败，请检查输入',
                        confirmButtonText: '确定'
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.fire({
                    icon: 'error',
                    title: '错误',
                    text: '输入有误，请检查',
                    confirmButtonText: '确定'
                });
            });
    });
});

$(document).ready(function () {
    $('#zhanghao').blur(function () {
        var username = $(this).val();
        if (username) {
            $.ajax({
                url: ROOTPATH + 'user_exist',
                type: "GET",
                data: {'username': username},
                success: function (response) {
                    if (response.exists) {
                        showError('#zhanghao', '#username-status', '账号已经存在');
                    } else {
                        removeError('#zhanghao', '#username-status');
                    }
                }
            });
        } else {
            removeError('#zhanghao', '#username-status');
        }
    });

    // 邮箱验证
    $('#email').blur(function () {
        var email = $(this).val();
        var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            showError('#email', '#email-status', '邮箱格式不正确');
        } else if (email) {
            $.ajax({
                url: ROOTPATH + 'user_email_exist',
                type: "GET",
                data: {'email': email},
                success: function (response) {
                    if (response.exists) {
                        showError('#email', '#email-status', '邮箱已经存在');
                    } else {
                        removeError('#email', '#email-status');
                    }
                }
            })
        } else {
            removeError('#email', '#email-status');
        }

    });

    // 密码验证
    $('#mima').blur(function () {
        var password = $(this).val();
        var passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/; // 至少8个字符，包含字母和数字
        if (!passwordRegex.test(password)) {
            showError('#mima', '#password-status', '密码格式不正确，至少8个字符，包含字母和数字');
        } else {
            removeError('#mima', '#password-status');
        }
    });

    // 电话验证
    $('#dianhua').blur(function () {
        var phone = $(this).val();
        var phoneRegex = /^\d{11}$/; // 假设电话号码是11位数字
        if (!phoneRegex.test(phone)) {
            showError('#dianhua', '#phone-status', '电话号码格式不正确');
        } else {
            removeError('#dianhua', '#phone-status');
        }
    });


    function showError(inputSelector, statusSelector, message) {
        $(inputSelector).addClass('is-invalid'); // 添加错误样式
        $(statusSelector).text(message).css('color', 'red');
    }

    function removeError(inputSelector, statusSelector) {
        $(inputSelector).removeClass('is-invalid'); // 移除错误样式
        $(statusSelector).text('');
    }
});


