// 从 Cookie 中获取 CSRF 令牌的函数
function getCookie(name) {
    var cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

function getSessionId() {
    var cookies = document.cookie.split(';');
    for (var i = 0; i < cookies.length; i++) {
        var cookie = cookies[i].trim();

        // 检查是否以 'sessionid=' 开头
        if (cookie.indexOf('sessionid=') === 0) {
            // 返回等号后面的部分作为 sessionid
            return cookie.substring('sessionid='.length);
        }
    }
    return null;
}


function generateCaptcha() {
    let chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    let captchaLength = 6;
    let captcha = '';
    for (let i = 0; i < captchaLength; i++) {
        let index = Math.floor(Math.random() * chars.length);
        captcha += chars[index];
    }
    document.getElementById('captcha-display').textContent = captcha;
}

function checkCaptcha() {
    let enteredCaptcha = document.getElementById('captcha').value.trim();
    let generatedCaptcha = document.getElementById('captcha-display').textContent.trim();
    if (enteredCaptcha === "") {
        Swal.fire({
            title: '验证码不能为空！',
            text: '',
            icon: 'error',
            confirmButtonText: '确定'
        });
        return false;
    }
    if (enteredCaptcha !== generatedCaptcha) {
        Swal.fire({
            title: '验证码错误！',
            text: '请重新输入！',
            icon: 'error',
            confirmButtonText: '确定'
        });
        generateCaptcha(); // 验证失败时重新生成验证码
        return false;
    }
    return true;
}


function jump1() {
    var zhanghao = document.getElementById("zhanghao").value;
    var mima = document.getElementById("mima").value;
    if (!checkCaptcha()) {
        return false; // 验证码检查未通过
    }
    if (zhanghao && mima) {
        $.ajax({
            url: ROOTPATH + 'sysuser_login', // 替换为实际的登录接口地址
            type: "POST",
            data: {zhanghao: zhanghao, mima: mima},

            beforeSend: function (xhr, settings) {
                var csrftoken = getCookie('csrftoken');
                xhr.setRequestHeader("X-CSRFToken", csrftoken);
            },
            success: function (data) {
                if (data == "0") {
                    Swal.fire({
                        title: '用户名或密码错误！',
                        text: '请重新输入！',
                        icon: 'error',
                        confirmButtonText: '确定'
                    })
                    document.getElementById("zhanghao").value = ""; // 清空用户名输入框
                    document.getElementById("mima").value = ""; // 清空密码输入框
                    return false;
                }
                Swal.fire({
                    title: '登录成功！',
                    text: '点击确定进入首页！',
                    icon: 'success',
                    confirmButtonText: '确定'
                }).then((result) => {
                    if (result.isConfirmed) {
                        console.log(ROOTPATH);
                        window.location.href = ROOTPATH; // 进入首页
                    }
                });
            }
            ,
            error: function (jqXHR, textStatus, err) {
                console.error("请求失败！", err);
            }
            ,
            complete: function (jqXHR, textStatus) {
                console.log("请求完成！", textStatus);
            }
            ,
            statusCode: {
                '403':

                    function (jqXHR, textStatus, err) {
                        console.error("请求被拒绝！", err);
                    }

                ,
                '400':

                    function (jqXHR, textStatus, err) {
                        console.error("错误的请求！", err);
                    }
            }
        });

    } else if (zhanghao == "" || mima == "") {
        Swal.fire({
            title: '用户名或密码不能为空！',
            text: '',
            icon: 'error',
            confirmButtonText: '确定'
        })
        return false;
    }
}





window.onload = generateCaptcha;