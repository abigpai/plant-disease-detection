function checkmima() {
    var mima = document.getElementById("R_pwd").value;
    var mima2 = document.getElementById("R_repwd").value;
    if (mima != "" || mima2 != "") {
        if (mima != mima2) {
            document.getElementById("tishi").innerHTML = "<font color='red'>两次输入密码不一致!</font>";
        }
    } else {
        document.getElementById("tishi").innerHTML = "<font color='red'></font>";
    }
}

function getCookie(name) {
    var cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

function jump() {
    // 创建 FormData 对象
    var formData = new FormData();
    // 获取表单数据
    var zhanghao = document.getElementById("zhanghao").value;
    var mima = document.getElementById("mima").value;
    var mima2 = document.getElementById("mima2").value;
    var email = document.getElementById("email").value;
    // var zhaopian = document.getElementById("zhaopian").files[0];
    // if (zhaopian) {
    //     formData.append("zhaopian", zhaopian);
    // }


    formData.append("zhanghao", zhanghao);
    formData.append("mima", mima);
    formData.append("email", email);
    ;



    // 验证输入
    var emailRegEx = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!email || !zhanghao || !mima) {
        Swal.fire({
            title: '邮箱、用户名或密码不能为空！',
            text: '请重新输入！',
            icon: 'error',
            confirmButtonText: '确定'
        });
        return;
    }

    if (!emailRegEx.test(email)) {
        Swal.fire({
            title: '邮箱格式不正确！',
            text: '请重新输入！',
            icon: 'error',
            confirmButtonText: '确定'
        });
        return;
    }

    if (mima !== mima2) {
        Swal.fire({
            title: '两次密码输入不一致！',
            text: '请重新输入！',
            icon: 'error',
            confirmButtonText: '确定'
        });
        return;
    }

    // 发起 AJAX 请求
    $.ajax({
        type: "POST",
        url: ROOTPATH + 'sysuser_register',
        data: formData,
        contentType: false, // 让浏览器自动设置 Content-Type
        processData: false, // 不对数据进行处理
        beforeSend: function (xhr) {
            var csrftoken = getCookie('csrftoken');
            xhr.setRequestHeader("X-CSRFToken", csrftoken);
        },
        success: function (data) {
            if (data === "0") {
                Swal.fire({
                    title: '注册成功！',
                    text: '点击确定去登录！',
                    icon: 'success',
                    confirmButtonText: '确定'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = ROOTPATH + 'sysuser_login';
                    }
                });
            } else if (data === "1") {
                Swal.fire({
                    title: '注册信息有误！',
                    text: '用户已存在！',
                    icon: 'error',
                    confirmButtonText: '确定'
                });
            } else if (data === "2") {
                Swal.fire({
                    title: '注册信息有误！',
                    text: '邮箱已存在！',
                    icon: 'error',
                    confirmButtonText: '确定'
                });
            } else {
                Swal.fire({
                    title: '注册信息有误！',
                    text: '请检查输入并重试。',
                    icon: 'error',
                    confirmButtonText: '确定'
                });
            }
        },
        error: function (xhr, status, error) {
            Swal.fire({
                title: '提交失败！',
                text: '请检查网络连接并重试。',
                icon: 'error',
                confirmButtonText: '确定'
            });
        }
    });
}


function jump3() {
    window.location.href = ROOTPATH + 'syszhanghao_login';
}