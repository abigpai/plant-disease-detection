"""
URL configuration for 基于卷积神经网络的茶叶病虫害检测系统 project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,re_path,include
from sysuser.views import logout_view

urlpatterns = [
    path('admin/logout/', logout_view, name='logout_view'),
    path("admin/", admin.site.urls),
    path('simpleui_captcha/', include('simpleui_captcha.urls')), # 后台登录验证码
    path('',include('appcenter.urls',namespace='appcenter')),
    path('', include('appconfig.urls', namespace='appconfig')),
    path('', include('apptools.urls', namespace='apptools')),
    path('', include('sysuser.urls', namespace='sysuser')),
]

