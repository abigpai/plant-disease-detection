from django.apps import AppConfig


class ApptoolsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apptools"
    verbose_name = "应用工具"
