# 导入数据库配置
from 基于卷积神经网络的茶叶病虫害检测系统.settings import DATABASE_NAME, DATABASE_USER, DATABASE_PSW, DATABASE_PORT, \
    DATABASE_HOST
import pymysql
import os
import django
from django.apps import apps
from django.shortcuts import redirect
#获取已经注册的model的name
def get_app_models(self_model=None):
    # 设置环境变量并初始化Django
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', '模板系统.settings')
    django.setup()

    # 获取所有已注册的应用程序
    registered_apps = apps.get_app_configs()
    if not self_model:


        # 使用列表推导获取所有模型的名称
        model_names = [model.__name__ for app in registered_apps for model in app.get_models()]

        # 打印模型名称
        print(model_names)
        return model_names
    else:


        # 使用列表推导获取所有非Django内置应用的模型名称
        model_names = [
            model.__name__
            for app in registered_apps
            if not app.path.startswith(os.path.dirname(django.__file__))
            for model in app.get_models()
        ]

        # 打印模型名称
        print(model_names)
        return model_names



import time
from threading import Thread

# 自定义线程类
# 自定义线程类
class MyThread(Thread):
    def __init__(self, target, args=(), kwargs=None):
        super().__init__()
        if kwargs is None:
            kwargs = {}
        self._target = target
        self._args = args
        self._kwargs = kwargs
        self._return = None

    def run(self):
        if self._target:
            self._return = self._target(*self._args, **self._kwargs)

    def join(self, *args, **kwargs):
        super().join(*args, **kwargs)
        return self._return

# 装饰器：测量执行时间
def time_spend(origin):
    def inner(*args, **kwargs):
        start = time.time()
        res = origin(*args, **kwargs)
        end = time.time()
        time_spent = end - start
        print('{}预计花费时间：'.format(origin.__name__), time_spent)
        return res
    return inner

# 装饰器：在新线程中运行函数
def simple_thread(origin):
    def inner(*args, **kwargs):
        thread = MyThread(target=origin, args=args, kwargs=kwargs)
        thread.start()
        return thread
    return inner


#这两个装饰器实现异步MySQL数据库查询
@simple_thread
@time_spend
def get_mysql_data(sql=None, data=None):
    # sql可以传入%的形式加上data防止sql注入
    print("数据库链接成功！")
    print('SQL语句:',sql)

    conn = pymysql.connect(host=DATABASE_HOST, port=DATABASE_PORT, user=DATABASE_USER, password=DATABASE_PSW,
                           db=DATABASE_NAME,
                           charset='utf8mb4')

    # 注意使用下面链接hive，这个数据库是hive的数据库，端口改为虚拟机的ip，需要将这个使用的mysql的所有表和数据导入到hive的库中
    # from pyhive.hive import Connection
    # conn = Connection(host="10.18.1.205",
    #                   port=10000,
    #                   database="hotel",
    #                   username="dsj_admin",
    #                   password="admin",
    #                   auth='CUSTOM',  # 使用自定义身份验证
    #                   configuration={'hive.server2.transport.mode': 'http',
    #                                  'hive.server2.thrift.http.path': '/cliservice'}
    #                   )
    cursor = conn.cursor()
    visual_data = None
    try:
        cursor.execute(sql, data)
        print("sql:" + sql)
        conn.commit()
        visual_data = cursor.fetchall()
    except Exception as e:
        print('错误！原因是{}'.format(e))
        conn.rollback()
    finally:
        print("数据库链接关闭！")
        cursor.close()
        conn.close()
    print('数据库返回数据为：',visual_data)
    return visual_data

def my_login_required(view_func):
    # 实现检测登录状态
    from functools import wraps
    @wraps(view_func)
    def _wrapped_view(request, *args, **kwargs):
        print('当前用户：',request.user)

        if not request.user.is_authenticated:
            print('未登录！')
            # 未登录会跳转登录页
            return redirect('sysuser:sysuser_login')
        return view_func(request, *args, **kwargs)
    return _wrapped_view
