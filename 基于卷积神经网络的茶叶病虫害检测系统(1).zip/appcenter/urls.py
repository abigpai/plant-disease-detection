from django.urls import path,re_path,include

from .views import *
app_name = 'appcenter'
from django.urls import path,re_path,include
urlpatterns = [
    path('',index,name='index'),
    path('shibie',shibie,name='shibie'),
    path('shibielog',shibielog,name='shibielog'),
    path('jiucuo',jiucuo,name='jiucuo'),
    path('yf',yf,name='yf'),

]
