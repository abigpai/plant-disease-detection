from django.apps import AppConfig


class AppcenterConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "appcenter"
    verbose_name = "应用中心"
