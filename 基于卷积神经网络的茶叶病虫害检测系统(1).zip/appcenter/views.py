#coding:utf-8
from django.shortcuts import render,HttpResponse
from django.http import JsonResponse
from datetime import datetime
import torch
from torch import nn
from torchvision import transforms
from PIL import Image
from sysuser.models import *
from apptools.apptools import *
from ultralytics import YOLO
@my_login_required
def index(request,page_number=1):
    if request.method == 'GET':
        user_login = request.user.is_authenticated
        if user_login:
            user = request.user

        lishijilu = IdentifyLog.objects.all()

        # 获取模型的所有字段及其中文名字
        fields_with_verbose_name = {
            field.name: field.verbose_name
            for field in IdentifyLog._meta.get_fields()
            if field.name != "id"  # 排除默认的自增id字段
        }

        # 打印字段名及其中文名字
        chinese_name_list = []
        for field_name, verbose_name in fields_with_verbose_name.items():
            chinese_name_list.append(verbose_name)
            print(f"字段名: {field_name}, 中文名字: {verbose_name}")
        chinese_name_list = chinese_name_list[:4]
        print(chinese_name_list)
        page_number = int(page_number)
        if page_number > 0:
            tables1 = IdentifyLog.objects.all().order_by('-time')[:4]

            tables = tables1.values()

        return render(request, 'app/index.html', locals())
    elif request.method == 'POST':
        return render(request, 'app/index.html', locals())



@my_login_required
def shibie(request):
    if request.method == 'POST':
        uploaded_file = request.FILES.get('image')
        path = os.path.join(os.path.dirname(os.path.dirname(__file__)))
        print('当前目录地址为：',path)
        now_time = datetime.now().strftime('%Y-%m-%d %H-%M-%S')
        uploaded_file_name = request.FILES['image'].name.split('.')[0] + now_time + '.' + \
                             request.FILES['image'].name.split('.')[1]

        media_path = os.path.join(path, 'media')
        img = Image.open(uploaded_file)
        img = img.resize((520,360))
        print(img)
        print('上传文件名为：', uploaded_file_name,'\n','上传地址为：',media_path)
        with open(r'{}/identify_log/{}'.format(media_path, uploaded_file_name), 'wb') as f:
            img.save(f, format='JPEG')
        # 深度学习加载模型需要的包
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        # 定义模型


        labels = ['藻叶','炭疽病', '鸟眼斑','褐斑病','灰光','健康','红叶斑','白点']


        # 加载模型

        # loaded_model.load_state_dict(torch.load('{}\\trainmodel\\trained_model.pth'.format(path)))
        model_path = os.path.join(path,'static','train_model','best.pt')
        model = YOLO(model_path)

        # 指定图像路径
        img_path = r'{}/identify_log/{}'.format(media_path, uploaded_file_name)  # 替换为你的图像路径
        results = model.predict(img_path)

        # 确保预测结果非空
        if results:
            # YOLOv8 分类任务结果通常返回的是 Probs 对象
            predictions = results[0].probs

            # 获取最高概率的类别及其置信度
            top_class = predictions.top1
            top_class_name = labels[top_class]
            confidence = predictions.top1conf.cpu().numpy()

            print(f'Predicted Class: {top_class}, Predicted Class Name: {top_class_name},Confidence: {confidence:.2f}')
        else:
            print("No prediction could be made for the image.")


        predicted_label = top_class_name
        print("Predicted class:", predicted_label)
        print("Confidence:", confidence)

        predicted_class_name = predicted_label
        print(uploaded_file_name)
        from django.db.models import Q
        querry = Q()
        querry &= Q(name__iregex=predicted_class_name)
        results = Yf.objects.filter(querry).values()[0]['defend']
        print(results)
        img_path = 'identify_log/{}'.format(uploaded_file_name)
        if predicted_class_name:
            log = IdentifyLog.objects.create(name=uploaded_file_name, time=now_time, result=predicted_class_name,image=img_path)
        else:
            log = IdentifyLog.objects.create(name=uploaded_file_name, time=now_time,
                                             result='预测失败！原因：图片加载失败！')

        # 打印结果
        print("识别后的结果是:", predicted_class_name)
        id = log.id
        result = {'result': str(predicted_class_name) + '\n' +'<p>'+'置信度：' + str(confidence)+'<p/>'+'防治措施：'+str(results), 'id': id}
        return JsonResponse(result)
    elif request.method == 'GET':
        return render(request, 'app/shibie.html')


def shibielog(request):

    log = IdentifyLog.objects.all().order_by('-time')


    return render(request, 'app/shibielog.html', locals())


def jiucuo(request):
    # result_real = request.POST.get('result_real')
    print(request.POST)
    id = request.POST.get('id')
    result_real = request.POST.get('result_real')
    log = IdentifyLog.objects.filter(id=id).update(result_real=result_real)
    return HttpResponse('1')


def yf(request,page_number=1):
    # 获取模型的所有字段及其中文名字
    fields_with_verbose_name = {
        field.name: field.verbose_name
        for field in Yf._meta.get_fields()
        if field.name != "id"  # 排除默认的自增id字段
    }

    # 打印字段名及其中文名字
    chinese_name_list = []
    for field_name, verbose_name in fields_with_verbose_name.items():
        chinese_name_list.append(verbose_name)
        print(f"字段名: {field_name}, 中文名字: {verbose_name}")
    chinese_name_list = chinese_name_list[:4]
    print(chinese_name_list)
    page_number = int(page_number)
    if page_number > 0:
        tables1 = Yf.objects.all()

        tables = tables1.values()
    return render(request, 'app/yf.html', locals())